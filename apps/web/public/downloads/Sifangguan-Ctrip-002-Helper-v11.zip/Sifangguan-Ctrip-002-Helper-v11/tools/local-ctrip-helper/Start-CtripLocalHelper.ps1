$ErrorActionPreference = 'Stop'

$helperRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent (Split-Path -Parent $helperRoot)
$bundledNode = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe'
$bundledPlaywright = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules\playwright\index.js'
$node = if (Test-Path -LiteralPath $bundledNode) {
  $bundledNode
} else {
  (Get-Command node -ErrorAction Stop).Source
}

if (Test-Path -LiteralPath $bundledPlaywright) {
  $env:UAT_PLAYWRIGHT_MODULE = $bundledPlaywright
} elseif (-not (Test-Path -LiteralPath (Join-Path $helperRoot 'node_modules\playwright-core\index.js'))) {
  throw '未找到浏览器运行组件。请先在本目录运行 npm install --omit=dev。'
}

$env:CTRIP_HELPER_ALLOWED_ORIGINS = 'https://www.sfgzt.cn'
Set-Location -LiteralPath $repoRoot
& $node (Join-Path $helperRoot 'ctrip-local-helper.mjs')
