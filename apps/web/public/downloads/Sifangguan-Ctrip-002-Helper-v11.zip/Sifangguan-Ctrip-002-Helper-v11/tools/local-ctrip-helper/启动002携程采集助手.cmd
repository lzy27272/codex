@echo off
setlocal
chcp 65001 >nul
set "HELPER_DIR=%~dp0"
set "REPO_ROOT=%HELPER_DIR%..\.."
set "BUNDLED_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
set "BUNDLED_PLAYWRIGHT=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules\playwright\index.js"

if exist "%BUNDLED_NODE%" (
  set "NODE_EXE=%BUNDLED_NODE%"
) else (
  where node >nul 2>nul
  if errorlevel 1 goto missing_node
  set "NODE_EXE=node"
)

if exist "%BUNDLED_PLAYWRIGHT%" (
  set "UAT_PLAYWRIGHT_MODULE=%BUNDLED_PLAYWRIGHT%"
) else if not exist "%HELPER_DIR%node_modules\playwright-core\index.js" (
  goto missing_runtime
)

set "CTRIP_HELPER_ALLOWED_ORIGINS=https://www.sfgzt.cn"
cd /d "%REPO_ROOT%"
"%NODE_EXE%" "%HELPER_DIR%ctrip-local-helper.mjs"
goto end

:missing_node
echo 未找到 Node.js。当前试点请在安装了 Codex 或 Node.js 的电脑运行。
goto end

:missing_runtime
echo 未找到浏览器运行组件。请在 tools\local-ctrip-helper 目录运行 npm install --omit=dev。

:end
echo.
pause
endlocal
