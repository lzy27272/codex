import { createHash } from 'node:crypto'
import { existsSync, mkdirSync } from 'node:fs'
import { createServer } from 'node:http'
import { createRequire } from 'node:module'
import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import process from 'node:process'

import {
  classifyCtripSessionProbeError,
  ctripCookieHeaderForEndpoint,
  ctripSummaryMatchesAnchor,
  validateCtripTrialSource,
} from '../uat/ctrip-controlled-login.mjs'
import { collectOtaSource } from '../uat/ota-source-collector.mjs'

const require = createRequire(import.meta.url)

export const CTRIP_LOCAL_HELPER_HOST = '127.0.0.1'
export const CTRIP_LOCAL_HELPER_PORT = 17_891
export const CTRIP_LOCAL_HELPER_VERSION = '1.0.0'
export const CTRIP_LOCAL_HELPER_HOTEL_CODE = '002'
export const CTRIP_LOCAL_HELPER_PLATFORM_CODE = 'CTRIP'

const ENDPOINT =
  'https://ebooking.ctrip.com/restapi/soa2/27204/queryOrderList'
const PORTAL = 'https://ebooking.ctrip.com/'
const DEFAULT_WAIT_MS = 10 * 60_000
const COOKIE_POLL_MS = 2_000
const REPROBE_MS = 5_000
const MAX_SOURCE_PROBES = 120
const MAX_REQUEST_BYTES = 2_048
const ALLOWED_DIMENSIONS = new Set([
  'PRICE',
  'SALES',
  'CHANNEL',
  'CANCELLATION',
  'ORDER',
  'DATE',
])

export const ctripLocalHelperSource = Object.freeze({
  sourceId: 'ctrip-local-helper-002',
  enabled: true,
  platformCode: CTRIP_LOCAL_HELPER_PLATFORM_CODE,
  displayName: '携程订单',
  portalUrl: PORTAL,
  dataEndpointUrl: ENDPOINT,
  requestMethod: 'GET',
  requestPayloadJson: '',
  lastSummary: {
    httpStatus: 200,
    rootType: 'object',
    recordPath: '$.orderList',
    detectedDimensions: ['PRICE', 'SALES', 'CHANNEL', 'CANCELLATION'],
  },
})

const expectedHotelNames = Object.freeze([
  '解放路MOOODSHIFT酒店',
  '解放路MOODSHIFT酒店',
  'MOOODSHIFT酒店',
])

const safeAllowedOrigins = (value = process.env.CTRIP_HELPER_ALLOWED_ORIGINS) =>
  new Set(
    String(value || 'https://www.sfgzt.cn')
      .split(',')
      .map((item) => item.trim())
      .filter((item) => /^https:\/\/[a-z0-9.-]+(?::\d{1,5})?$/iu.test(item)
        || /^http:\/\/(?:127\.0\.0\.1|localhost)(?::\d{1,5})?$/iu.test(item)),
  )

const localDataRoot = () => resolve(
  process.env.CTRIP_HELPER_DATA_ROOT
  || join(
    process.env.LOCALAPPDATA || join(homedir(), 'AppData', 'Local'),
    'Sifangguan',
    'CtripHelper002',
  ),
)

const browserExecutableFor = () =>
  process.env.CTRIP_BROWSER_EXECUTABLE
  || [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  ].find(existsSync)

const chromiumFor = () => {
  try {
    const moduleName = process.env.UAT_PLAYWRIGHT_MODULE || 'playwright-core'
    return require(moduleName).chromium
  } catch {
    throw new Error('LOCAL_HELPER_BROWSER_RUNTIME_UNAVAILABLE')
  }
}

const wait = (milliseconds) => new Promise((resolveWait) =>
  setTimeout(resolveWait, milliseconds))

const helperErrorCode = (error) => {
  const code = String(error?.message || '')
  if (/^[A-Z][A-Z0-9_]{2,80}$/u.test(code)) return code
  if (/browser.*closed|target page.*closed/iu.test(code)) {
    return 'LOCAL_HELPER_BROWSER_CLOSED'
  }
  return 'LOCAL_HELPER_COLLECTION_FAILED'
}

export const sanitizeCtripCapture = (summary, capturedAt = new Date()) => {
  if (
    !summary
    || summary.httpStatus !== 200
    || summary.hotelScopeEvidence?.provider !== 'CTRIP'
    || summary.hotelScopeEvidence?.status !== 'MATCHED'
    || !Number.isInteger(summary.recordCount)
    || summary.recordCount < 0
  ) {
    throw new Error('LOCAL_HELPER_CAPTURE_NOT_VERIFIED')
  }
  const dimensions = Array.isArray(summary.detectedDimensions)
    ? summary.detectedDimensions
      .filter((item) => ALLOWED_DIMENSIONS.has(String(item)))
      .slice(0, 12)
    : []
  return Object.freeze({
    status: 'CAPTURED',
    loginState: 'AUTHENTICATED',
    hotelCode: CTRIP_LOCAL_HELPER_HOTEL_CODE,
    platformCode: CTRIP_LOCAL_HELPER_PLATFORM_CODE,
    capturedAt: capturedAt.toISOString(),
    dataScope: '携程订单列表当前查询结果',
    recordCount: summary.recordCount,
    detectedDimensions: dimensions,
    hotelScopeStatus: 'VERIFIED_FROM_CTRIP_RESPONSE',
    stableIdentityStatus:
      summary.hotelScopeEvidence?.stableIdentityStatus || 'UNAVAILABLE',
  })
}

export const collectWithPersistentCtripBrowser = async ({
  chromium = chromiumFor(),
  executablePath = browserExecutableFor(),
  profilePath = join(localDataRoot(), 'chrome-profile'),
  collectSource = collectOtaSource,
  now = () => new Date(),
  sleep = wait,
  maxWaitMs = DEFAULT_WAIT_MS,
  onState = () => {},
} = {}) => {
  const { portal, endpoint, anchor } = validateCtripTrialSource(
    ctripLocalHelperSource,
  )
  if (!executablePath || !existsSync(executablePath)) {
    throw new Error('LOCAL_HELPER_BROWSER_NOT_FOUND')
  }
  if (!Number.isFinite(maxWaitMs) || maxWaitMs < 1 || maxWaitMs > 30 * 60_000) {
    throw new Error('LOCAL_HELPER_WAIT_POLICY_INVALID')
  }
  mkdirSync(profilePath, { recursive: true })
  let context
  let cookieHeader = ''
  try {
    context = await chromium.launchPersistentContext(profilePath, {
      headless: false,
      executablePath,
      acceptDownloads: false,
      locale: 'zh-CN',
      timezoneId: 'Asia/Shanghai',
      viewport: null,
      args: [
        '--start-maximized',
        '--disable-features=PasswordManagerOnboarding,PasswordLeakDetection',
        '--disable-save-password-bubble',
        '--no-default-browser-check',
        '--no-first-run',
      ],
    })
    const page = context.pages().find((candidate) => !candidate.isClosed())
      || await context.newPage()
    onState('OPENING_CTRIP_OFFICIAL_LOGIN')
    if (!page.url().startsWith(portal.origin)) {
      await page.goto(portal.href, {
        waitUntil: 'domcontentloaded',
        timeout: 45_000,
      })
    }
    onState('WAITING_FOR_USER_LOGIN')

    const deadline = now().getTime() + maxWaitMs
    let lastCookieFingerprint = null
    let lastProbeAt = Number.NEGATIVE_INFINITY
    let probeCount = 0
    let lastScopeStatus = null
    while (now().getTime() < deadline) {
      if (!context.pages().some((candidate) => !candidate.isClosed())) {
        throw new Error('LOCAL_HELPER_BROWSER_CLOSED')
      }
      const cookies = await context.cookies(endpoint.href)
      cookieHeader = ctripCookieHeaderForEndpoint(
        cookies,
        endpoint.href,
        now().getTime(),
      )
      const fingerprint = cookieHeader
        ? createHash('sha256').update(cookieHeader).digest('hex')
        : null
      const currentTime = now().getTime()
      const shouldProbe = fingerprint && (
        fingerprint !== lastCookieFingerprint
        || currentTime - lastProbeAt >= REPROBE_MS
      )
      if (shouldProbe) {
        lastCookieFingerprint = fingerprint
        lastProbeAt = currentTime
        probeCount += 1
        if (probeCount > MAX_SOURCE_PROBES) {
          throw new Error('LOCAL_HELPER_PROBE_LIMIT_REACHED')
        }
        let summary
        try {
          onState('VERIFYING_CTRIP_SESSION')
          summary = await collectSource({
            source: ctripLocalHelperSource,
            cookie: cookieHeader,
            expectedHotelNames,
            discoverHotelIdentity: true,
          })
        } catch (error) {
          const classification = classifyCtripSessionProbeError(error)
          if (classification === 'PERMISSION_DENIED') {
            throw new Error('LOCAL_HELPER_SOURCE_PERMISSION_DENIED')
          }
          if (classification === 'FATAL') throw error
          onState('WAITING_FOR_VALID_CTRIP_SESSION')
          await sleep(COOKIE_POLL_MS)
          continue
        } finally {
          cookieHeader = ''
        }
        if (!ctripSummaryMatchesAnchor(summary, anchor)) {
          onState('WAITING_FOR_VALIDATED_CTRIP_SOURCE_SCHEMA')
          await sleep(COOKIE_POLL_MS)
          continue
        }
        lastScopeStatus = summary.hotelScopeEvidence?.status || 'UNAVAILABLE'
        if (lastScopeStatus !== 'MATCHED') {
          onState(`WAITING_FOR_HOTEL_SCOPE_${lastScopeStatus}`)
          await sleep(COOKIE_POLL_MS)
          continue
        }
        onState('CAPTURED')
        return sanitizeCtripCapture(summary, now())
      }
      await sleep(COOKIE_POLL_MS)
    }
    if (lastScopeStatus === 'MISMATCH') {
      throw new Error('LOCAL_HELPER_HOTEL_SCOPE_MISMATCH')
    }
    if (lastScopeStatus === 'AMBIGUOUS') {
      throw new Error('LOCAL_HELPER_HOTEL_SCOPE_AMBIGUOUS')
    }
    throw new Error('LOCAL_HELPER_LOGIN_TIMEOUT')
  } catch (error) {
    throw new Error(helperErrorCode(error))
  } finally {
    cookieHeader = ''
    await context?.close?.().catch(() => {})
  }
}

const jsonResponse = (response, statusCode, value, origin = null) => {
  response.statusCode = statusCode
  response.setHeader('Content-Type', 'application/json; charset=utf-8')
  response.setHeader('Cache-Control', 'no-store')
  response.setHeader('X-Content-Type-Options', 'nosniff')
  if (origin) {
    response.setHeader('Access-Control-Allow-Origin', origin)
    response.setHeader('Vary', 'Origin')
    response.setHeader('Access-Control-Allow-Private-Network', 'true')
  }
  response.end(JSON.stringify(value))
}

const requestBodyWithinLimit = (request) => new Promise((resolveBody, reject) => {
  let bytes = 0
  request.on('data', (chunk) => {
    bytes += chunk.length
    if (bytes > MAX_REQUEST_BYTES) {
      reject(new Error('LOCAL_HELPER_REQUEST_TOO_LARGE'))
      request.destroy()
    }
  })
  request.on('end', resolveBody)
  request.on('error', reject)
})

export const createCtripLocalHelperServer = ({
  allowedOrigins = safeAllowedOrigins(),
  collect = collectWithPersistentCtripBrowser,
  state = { value: 'READY' },
} = {}) => {
  let activeCollection = null
  return createServer(async (request, response) => {
    const origin = typeof request.headers.origin === 'string'
      ? request.headers.origin
      : null
    if (!origin || !allowedOrigins.has(origin)) {
      return jsonResponse(response, 403, {
        error: { code: 'LOCAL_HELPER_ORIGIN_REJECTED' },
      })
    }
    if (request.method === 'OPTIONS') {
      response.statusCode = 204
      response.setHeader('Access-Control-Allow-Origin', origin)
      response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
      response.setHeader('Access-Control-Allow-Headers', 'Content-Type')
      response.setHeader('Access-Control-Allow-Private-Network', 'true')
      response.setHeader('Access-Control-Max-Age', '600')
      response.setHeader('Vary', 'Origin')
      return response.end()
    }
    if (request.method === 'GET' && request.url === '/health') {
      return jsonResponse(response, 200, {
        data: {
          status: state.value,
          helperVersion: CTRIP_LOCAL_HELPER_VERSION,
          hotelCode: CTRIP_LOCAL_HELPER_HOTEL_CODE,
          platformCode: CTRIP_LOCAL_HELPER_PLATFORM_CODE,
        },
      }, origin)
    }
    if (request.method === 'POST' && request.url === '/api/v1/ctrip/collect') {
      try {
        await requestBodyWithinLimit(request)
      } catch (error) {
        return jsonResponse(response, 413, {
          error: { code: helperErrorCode(error) },
        }, origin)
      }
      if (activeCollection) {
        return jsonResponse(response, 409, {
          error: { code: 'LOCAL_HELPER_COLLECTION_IN_PROGRESS' },
        }, origin)
      }
      state.value = 'COLLECTING'
      activeCollection = collect({
        onState: (nextState) => { state.value = nextState },
      })
      try {
        const data = await activeCollection
        state.value = 'READY'
        return jsonResponse(response, 200, { data }, origin)
      } catch (error) {
        state.value = 'READY'
        return jsonResponse(response, 422, {
          error: { code: helperErrorCode(error) },
        }, origin)
      } finally {
        activeCollection = null
      }
    }
    return jsonResponse(response, 404, {
      error: { code: 'LOCAL_HELPER_ROUTE_NOT_FOUND' },
    }, origin)
  })
}

export const startCtripLocalHelper = ({
  host = CTRIP_LOCAL_HELPER_HOST,
  port = Number(process.env.CTRIP_HELPER_PORT || CTRIP_LOCAL_HELPER_PORT),
} = {}) => {
  if (host !== CTRIP_LOCAL_HELPER_HOST) {
    throw new Error('LOCAL_HELPER_LOOPBACK_REQUIRED')
  }
  const server = createCtripLocalHelperServer()
  server.listen(port, host, () => {
    process.stdout.write(
      `Sifangguan Ctrip helper ready on http://${host}:${port}\n`,
    )
  })
  return server
}

const invokedAsScript = process.argv[1]
  && import.meta.url === pathToFileURL(resolve(process.argv[1])).href

if (invokedAsScript) {
  startCtripLocalHelper()
}
