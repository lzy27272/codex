import { createHash } from 'node:crypto'
import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import process from 'node:process'

import { collectOtaSource } from './ota-source-collector.mjs'

const require = createRequire(import.meta.url)
const CTRIP_PORTAL_HOST = 'ebooking.ctrip.com'
const CTRIP_SOURCE_PATH = '/restapi/soa2/27204/queryOrderList'
const CTRIP_COOKIE_BASE_DOMAIN = 'ctrip.com'
const DEFAULT_LOGIN_TIMEOUT_MS = 10 * 60_000
const DEFAULT_POLL_INTERVAL_MS = 2_000
const PERIODIC_SCOPE_REPROBE_MS = 15_000
const MAX_SOURCE_PROBES = 12
const MAX_COOKIE_COUNT = 200
const MAX_COOKIE_HEADER_BYTES = 64 * 1024

let cachedChromium = null

const chromiumFor = () => {
  if (cachedChromium) return cachedChromium
  try {
    const module = require(process.env.UAT_PLAYWRIGHT_MODULE ?? 'playwright')
    cachedChromium = module.chromium
    return cachedChromium
  } catch {
    throw new Error('OTA_CTRIP_BROWSER_RUNTIME_UNAVAILABLE')
  }
}

const browserExecutableFor = () =>
  process.env.CTRIP_BROWSER_EXECUTABLE
  || process.env.UAT_BROWSER_EXECUTABLE
  || [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium',
  ].find(existsSync)

const controlledDelay = (milliseconds) => new Promise(
  (resolveDelay) => setTimeout(resolveDelay, milliseconds),
)

const clockMilliseconds = (clock) => {
  const value = clock()
  const milliseconds = value instanceof Date ? value.getTime() : Number(value)
  if (!Number.isFinite(milliseconds)) {
    throw new Error('OTA_CTRIP_CLOCK_INVALID')
  }
  return milliseconds
}

const safeConfiguredUrl = (rawValue, expectedPath = null) => {
  let url
  try {
    url = new URL(rawValue)
  } catch {
    throw new Error('OTA_CTRIP_ENDPOINT_NOT_ALLOWED')
  }
  if (
    url.protocol !== 'https:'
    || url.hostname.toLowerCase() !== CTRIP_PORTAL_HOST
    || url.username
    || url.password
    || url.hash
    || (url.port && url.port !== '443')
    || (expectedPath !== null && url.pathname !== expectedPath)
  ) {
    throw new Error('OTA_CTRIP_ENDPOINT_NOT_ALLOWED')
  }
  return url
}

export const validateCtripTrialSource = (source) => {
  if (
    !source
    || typeof source !== 'object'
    || source.enabled !== true
    || source.platformCode !== 'CTRIP'
    || source.requestMethod !== 'GET'
  ) {
    throw new Error('OTA_CTRIP_SOURCE_NOT_ELIGIBLE')
  }
  const portal = safeConfiguredUrl(source.portalUrl)
  const endpoint = safeConfiguredUrl(
    source.dataEndpointUrl,
    CTRIP_SOURCE_PATH,
  )
  const anchor = source.lastSummary
  if (
    !anchor
    || String(anchor.rootType ?? '').toLowerCase() !== 'object'
    || anchor.recordPath !== '$.orderList'
    || !Array.isArray(anchor.detectedDimensions)
    || !anchor.detectedDimensions.includes('SALES')
  ) {
    throw new Error('OTA_CTRIP_SOURCE_ANCHOR_MISSING')
  }
  return { portal, endpoint, anchor }
}

const domainMatches = (rawDomain, host) => {
  const domain = String(rawDomain ?? '').trim().toLowerCase().replace(/^\./, '')
  return domain === CTRIP_COOKIE_BASE_DOMAIN
    || (
      domain.endsWith(`.${CTRIP_COOKIE_BASE_DOMAIN}`)
      && (host === domain || host.endsWith(`.${domain}`))
    )
}

const pathMatches = (cookiePath, requestPath) => {
  if (cookiePath === requestPath) return true
  if (!requestPath.startsWith(cookiePath)) return false
  return cookiePath.endsWith('/') || requestPath[cookiePath.length] === '/'
}

export const ctripCookieHeaderForEndpoint = (
  candidateCookies,
  rawEndpoint,
  nowMilliseconds = Date.now(),
) => {
  const endpoint = safeConfiguredUrl(rawEndpoint, CTRIP_SOURCE_PATH)
  if (
    !Array.isArray(candidateCookies)
    || candidateCookies.length > MAX_COOKIE_COUNT
  ) {
    throw new Error('OTA_CTRIP_SESSION_COOKIES_INVALID')
  }
  const header = candidateCookies
    .filter((cookie) => {
      if (!cookie || typeof cookie !== 'object' || Array.isArray(cookie)) {
        return false
      }
      const name = String(cookie.name ?? '')
      const value = String(cookie.value ?? '')
      const cookiePath = String(cookie.path ?? '/')
      const expires = Number(cookie.expires)
      return name.length > 0
        && name.length <= 256
        && value.length <= 8_192
        && !/[;\r\n\u0000]/u.test(name)
        && !/[;\r\n\u0000]/u.test(value)
        && domainMatches(cookie.domain, endpoint.hostname.toLowerCase())
        && cookiePath.startsWith('/')
        && cookiePath.length <= 1_024
        && pathMatches(cookiePath, endpoint.pathname)
        && (expires === -1 || (Number.isFinite(expires)
          && expires * 1_000 > nowMilliseconds))
    })
    .sort((left, right) => String(right.path ?? '/').length
      - String(left.path ?? '/').length)
    .map((cookie) => `${cookie.name}=${cookie.value}`)
    .join('; ')
  if (Buffer.byteLength(header, 'utf8') > MAX_COOKIE_HEADER_BYTES) {
    throw new Error('OTA_CTRIP_SESSION_COOKIES_INVALID')
  }
  return header
}

export const ctripSummaryMatchesAnchor = (summary, anchor) => Boolean(
  summary
  && Number(summary.httpStatus) === 200
  && String(summary.rootType ?? '').toLowerCase()
    === String(anchor?.rootType ?? '').toLowerCase()
  && summary.recordPath === anchor?.recordPath
  && Array.isArray(summary.detectedDimensions)
  && summary.detectedDimensions.includes('SALES')
)

export const classifyCtripSessionProbeError = (error) => {
  const code = String(error?.message ?? '')
  if ([
    'OTA_COOKIE_REQUIRED_FOR_REFRESH',
    'OTA_SESSION_INVALID',
    'OTA_RESPONSE_NOT_JSON',
    'OTA_HTTP_401',
  ].includes(code)) return 'WAIT_FOR_LOGIN'
  if (code === 'OTA_HTTP_403') return 'PERMISSION_DENIED'
  return 'FATAL'
}

const browserFailureCode = (error) => {
  const message = String(error?.message ?? '')
  if (/target page, context or browser has been closed|browser.*closed/i.test(message)) {
    return 'OTA_CTRIP_BROWSER_CLOSED'
  }
  if (/^OTA_[A-Z0-9_]+$/u.test(message)) return message
  return 'OTA_CTRIP_BROWSER_FAILED'
}

export const completeCtripPopupSourceLogin = async ({
  source,
  hotelName,
  hotelAliases = [],
  businessDate = null,
  chromium = null,
  executablePath = null,
  collectSource = collectOtaSource,
  clock = () => Date.now(),
  sleep = controlledDelay,
  maxWaitMs = DEFAULT_LOGIN_TIMEOUT_MS,
  pollIntervalMs = DEFAULT_POLL_INTERVAL_MS,
  notify = () => {},
}) => {
  const { portal, endpoint, anchor } = validateCtripTrialSource(source)
  const expectedHotelNames = [hotelName, ...hotelAliases]
  if (
    expectedHotelNames.some((value) =>
      typeof value !== 'string'
      || value.trim().length < 4
      || value.length > 256
      || /[\r\n\u0000]/u.test(value))
  ) {
    throw new Error('OTA_CTRIP_HOTEL_SCOPE_EXPECTATION_INVALID')
  }
  if (
    !Number.isFinite(maxWaitMs)
    || maxWaitMs < 1
    || maxWaitMs > 30 * 60_000
    || !Number.isFinite(pollIntervalMs)
    || pollIntervalMs < 1
  ) {
    throw new Error('OTA_CTRIP_LOGIN_POLICY_INVALID')
  }
  const browserExecutable = executablePath ?? browserExecutableFor()
  if (!browserExecutable || !existsSync(browserExecutable)) {
    throw new Error('OTA_CTRIP_BROWSER_NOT_FOUND')
  }
  let browser
  let context
  let cookieHeader = ''
  try {
    browser = await (chromium ?? chromiumFor()).launch({
      headless: false,
      executablePath: browserExecutable,
      args: [
        '--disable-features=PasswordManagerOnboarding,PasswordLeakDetection',
        '--disable-save-password-bubble',
        '--no-default-browser-check',
        '--no-first-run',
      ],
    })
    context = await browser.newContext({
      acceptDownloads: false,
      locale: 'zh-CN',
      timezoneId: 'Asia/Shanghai',
      viewport: { width: 1440, height: 960 },
    })
    const page = await context.newPage()
    notify({
      status: 'OPENING_CTRIP_OFFICIAL_LOGIN',
      portalOrigin: portal.origin,
    })
    await page.goto(portal.href, {
      waitUntil: 'domcontentloaded',
      timeout: 45_000,
    })
    notify({
      status: 'WAITING_FOR_USER_LOGIN',
      instruction: '请在携程官方窗口完成登录、扫码或短信验证',
    })

    const deadline = clockMilliseconds(clock) + maxWaitMs
    let lastCookieFingerprint = null
    let lastProbeAt = Number.NEGATIVE_INFINITY
    let lastScopeStatus = null
    let schemaValidatedOnce = false
    let probeCount = 0
    while (clockMilliseconds(clock) < deadline) {
      const openPages = context.pages().filter((candidate) => !candidate.isClosed())
      if (openPages.length < 1) throw new Error('OTA_CTRIP_BROWSER_CLOSED')
      const cookies = await context.cookies(endpoint.href)
      cookieHeader = ctripCookieHeaderForEndpoint(
        cookies,
        endpoint.href,
        clockMilliseconds(clock),
      )
      const fingerprint = cookieHeader
        ? createHash('sha256').update(cookieHeader).digest('hex')
        : null
      const nowMilliseconds = clockMilliseconds(clock)
      if (
        fingerprint
        && (
          fingerprint !== lastCookieFingerprint
          || (
            schemaValidatedOnce
            && nowMilliseconds - lastProbeAt >= PERIODIC_SCOPE_REPROBE_MS
          )
        )
      ) {
        lastCookieFingerprint = fingerprint
        lastProbeAt = nowMilliseconds
        probeCount += 1
        if (probeCount > MAX_SOURCE_PROBES) {
          throw new Error('OTA_CTRIP_LOGIN_PROBE_LIMIT_REACHED')
        }
        let summary
        try {
          summary = await collectSource({
            source,
            cookie: cookieHeader,
            businessDate,
            expectedHotelNames,
          })
        } catch (error) {
          const classification = classifyCtripSessionProbeError(error)
          if (classification === 'PERMISSION_DENIED') {
            throw new Error('OTA_CTRIP_SOURCE_PERMISSION_DENIED')
          }
          if (classification === 'FATAL') throw error
          notify({ status: 'WAITING_FOR_VALID_CTRIP_SESSION' })
          cookieHeader = ''
          await sleep(pollIntervalMs)
          continue
        } finally {
          cookieHeader = ''
        }
        if (ctripSummaryMatchesAnchor(summary, anchor)) {
          schemaValidatedOnce = true
          lastScopeStatus = summary.hotelScopeEvidence?.status ?? 'UNAVAILABLE'
          if (lastScopeStatus === 'MATCHED') {
            return {
              summary,
              hotelScopeStatus: 'VERIFIED_FROM_CTRIP_RESPONSE',
              probeCount,
            }
          }
          notify({
            status: lastScopeStatus === 'MISMATCH'
              ? 'WAITING_FOR_EXPECTED_CTRIP_HOTEL_SCOPE'
              : lastScopeStatus === 'AMBIGUOUS'
                ? 'WAITING_FOR_SINGLE_CTRIP_HOTEL_SCOPE'
                : 'WAITING_FOR_CTRIP_HOTEL_SCOPE_EVIDENCE',
            instruction: '请确认携程后台当前选择的是本次试点门店',
          })
          await sleep(pollIntervalMs)
          continue
        }
        notify({ status: 'WAITING_FOR_VALIDATED_CTRIP_SOURCE_SCHEMA' })
      }
      await sleep(pollIntervalMs)
    }
    if (lastScopeStatus === 'MISMATCH') {
      throw new Error('OTA_CTRIP_HOTEL_SCOPE_MISMATCH')
    }
    if (lastScopeStatus === 'UNAVAILABLE') {
      throw new Error('OTA_CTRIP_HOTEL_SCOPE_UNAVAILABLE')
    }
    if (lastScopeStatus === 'AMBIGUOUS') {
      throw new Error('OTA_CTRIP_HOTEL_SCOPE_AMBIGUOUS')
    }
    throw new Error('OTA_CTRIP_LOGIN_TIMEOUT')
  } catch (error) {
    throw new Error(browserFailureCode(error))
  } finally {
    cookieHeader = ''
    await context?.close?.().catch(() => {})
    await browser?.close?.().catch(() => {})
  }
}

export const ctripControlledLoginPolicy = Object.freeze({
  portalHost: CTRIP_PORTAL_HOST,
  sourcePath: CTRIP_SOURCE_PATH,
  maxWaitMinutes: DEFAULT_LOGIN_TIMEOUT_MS / 60_000,
  maxSourceProbes: MAX_SOURCE_PROBES,
  persistentSession: false,
})
